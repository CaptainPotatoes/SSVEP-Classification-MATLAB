function Y = Wstd(X)
    Y = std(X,[],2);
end