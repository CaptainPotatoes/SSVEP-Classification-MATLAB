function Y = Wmax(X)
    Y = max(X,[],2);
end