function Y = WCountMin(X)
    Y = sum(X<0.9,2);
end