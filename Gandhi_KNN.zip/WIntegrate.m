function Y = WIntegrate(X)
    Y = trapz(X,2);
end