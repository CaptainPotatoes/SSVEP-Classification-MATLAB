function Y = Wmin(X)
    Y = min(X,[],2);
end