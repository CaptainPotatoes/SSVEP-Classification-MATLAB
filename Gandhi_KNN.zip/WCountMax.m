function Y = WCountMax(X)
    Y = sum(X>1.5,2);
end