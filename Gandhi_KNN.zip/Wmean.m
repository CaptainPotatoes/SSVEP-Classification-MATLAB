function Y = Wmean(X)
    Y = mean(X,2);
end